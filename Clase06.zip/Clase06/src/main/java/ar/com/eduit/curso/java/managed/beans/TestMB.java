package ar.com.eduit.curso.java.managed.beans;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named()
@SessionScoped
public class TestMB implements Serializable{
    private String nombre="Ingrese su nombre";

    public void imprimir(){
        System.out.println(nombre);
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
