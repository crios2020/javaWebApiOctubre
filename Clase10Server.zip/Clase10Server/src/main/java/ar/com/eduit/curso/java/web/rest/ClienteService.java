package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ClienteRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.lang.reflect.Type;
import java.util.List;

@Path("/clientes/v1")
public class ClienteService {
    
    private I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio Clientes V1 Activo!";
    }
    
    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
//        Gson gson=new Gson();
//        List<Cliente>list=cr.getAll();
//        String r=gson.toJson(list);
//        return r;
        return new Gson().toJson(cr.getAll());
    }
    
    @GET
    @Path("/byId")
    @Produces(MediaType.APPLICATION_JSON)
    public String getById(@QueryParam("id") int id){
        return new Gson().toJson(cr.getById(id));
    }
    
    @GET
    @Path("/likeApellido")
    @Produces(MediaType.APPLICATION_JSON)
    public String getLikeApellido(@QueryParam("apellido") String apellido){
        return new Gson().toJson(cr.getLikeApellido(apellido));
    }
    
    @GET
    @Path("/alta")
    @Produces(MediaType.TEXT_PLAIN)
    public int save(    
                        @QueryParam("nombre") String nombre,
                        @QueryParam("apellido") String apellido,
                        @QueryParam("edad") int edad,
                        @QueryParam("idArticulo") int idArticulo
    ){
        Cliente cliente=new Cliente(nombre, apellido, edad, idArticulo);
        cr.save(cliente);
        return cliente.getId();
    }
    
    @GET
    @Path("/alta2")
    @Produces(MediaType.TEXT_PLAIN)
    public int save(@QueryParam("clienteJson")String clienteJson){
        clienteJson="{"+clienteJson+"}";
        //System.out.println(clienteJson);
        Type type=new TypeToken<Cliente>(){}.getType();
        Cliente cliente=new Gson().fromJson(clienteJson, type);
        cr.save(cliente);
        return cliente.getId();
    }
    
}
