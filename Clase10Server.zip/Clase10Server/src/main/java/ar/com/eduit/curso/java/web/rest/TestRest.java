package ar.com.eduit.curso.java.web.rest;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/test")
public class TestRest {
    
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String info(){
        return "<h1>Hola Mundo JaxRS</h1>";
    }
    
    @GET
    @Path("/info2")
    @Produces(MediaType.TEXT_PLAIN)
    public String info2(){
        return "<h1>método info2</h1>";
    }
 
    @GET
    @Path("/saludar")
    @Produces(MediaType.TEXT_HTML)
    public String saludo(@QueryParam("nombre") String n){
        return "<h1>Hola "+n+"</h1>";
    }
    
    @GET
    @Path("/calculadora")
    @Produces(MediaType.TEXT_PLAIN)
    public String calculadora(@QueryParam("nro1")int nro1, @QueryParam("nro2")int nro2){
        return (nro1+nro2)+"";
    }
}
