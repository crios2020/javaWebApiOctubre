package clase03cliente;

import ar.com.eduit.curso.java.entities.Articulo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

public class Clase03Cliente {

    public static void main(String[] args) throws Exception{
        //System.out.println(responseBody("https://www.google.com.ar/"));
        //System.out.println(responseBody("http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=lavalle_648"));
    
        String urlServer="http://localhost:8082/Server/webresources/articulos/v1";
        System.out.println("****************************************************");
        System.out.println("Servicio Alta Articulos");
        System.out.println("****************************************************");
        System.out.println(responseBody(urlServer+"/alta?descripcion=Colchon&precio=4000&stock=30"));
        System.out.println(responseBody(urlServer+"/alta?descripcion=Cocina&precio=2000&stock=20"));
        System.out.println(responseBody(urlServer+"/alta?descripcion=Cuchillo&precio=4000&stock=30"));
        System.out.println(responseBody(urlServer+"/alta?descripcion=Carpa&precio=30000&stock=40"));
        System.out.println(responseBody(urlServer+"/alta?descripcion=Silla&precio=3000&stock=40"));
        
        
        System.out.println("****************************************************");
        System.out.println("Servicio Articulo All");
        System.out.println("****************************************************");
        System.out.println(responseBody(urlServer+"/all"));
        
        System.out.println("****************************************************");
        System.out.println("Servicio Articulo LikeDescripcion");
        System.out.println("****************************************************");
        System.out.println(responseBody(urlServer+"/likeDescripcion?descripcion=ca"));
        
        System.out.println("****************************************************");
        System.out.println("List<Articulo>");
        System.out.println("****************************************************");
        
        String url=urlServer+"/all";
        Type listType=new TypeToken<List<Articulo>>(){}.getType();
        List<Articulo>list=new Gson().fromJson(responseBody(url), listType);
        list.forEach(System.out::println);
    }
     
    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()==200){
            System.out.println("\033[32mstatus: "+response.statusCode()+"\033[0m");
        }else{
            System.out.println("\033[31mstatus: "+response.statusCode()+"\033[0m");
        }
        //response.headers().map().forEach((k, v) -> System.out.println(k + " " + v));
        return response.body();
    }
}
