package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ClienteRepository;
import com.google.gson.Gson;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("/clientes/v1")
public class ClienteService {
    
    private I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio Clientes V1 Activo!";
    }
    
    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
//        Gson gson=new Gson();
//        List<Cliente>list=cr.getAll();
//        String r=gson.toJson(list);
//        return r;
        return new Gson().toJson(cr.getAll());
    }
    
    @GET
    @Path("/byId")
    @Produces(MediaType.APPLICATION_JSON)
    public String getById(@QueryParam("id") int id){
        return new Gson().toJson(cr.getById(id));
    }
    
}
