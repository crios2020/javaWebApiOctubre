package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ArticuloRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ClienteRepository;
import ar.com.eduit.curso.java.repositories.list.ArticuloRepositoryFactory;

public class TestRepository {
    public static void main(String[] args) {
        
        //I_ArticuloRepository ar=ArticuloRepositoryFactory.getArticuloRepository();
        I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
        ar.save(new Articulo("Termo", 600, 20));
        ar.save(new Articulo("Pava Electrica", 1600, 10));
        ar.save(new Articulo("Conservadora", 700, 22));
        ar.save(new Articulo("Luz Camping", 500, 14));
        ar.getAll().forEach(System.out::println);
        //ar.getLikeDescripcion("ca").forEach(System.out::println);
        
        I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
        cr.save(new Cliente("Kassandra","Vargas",23,1));
        cr.save(new Cliente("Andrea","Moretti",26,2));
        cr.save(new Cliente("Javier","Correa",29,3));
        cr.save(new Cliente("Jose","Riera",39,4));
        cr.getAll().forEach(System.out::println);
        
    }
}
