package ar.com.eduit.curso.java.managed.beans;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named()
@SessionScoped
public class MenuMB implements Serializable{
    private String inicio="http://localhost:8080/Clase10ClientePrimefaces";
    private String clientes=inicio+"/faces/clientes.xhtml";
    private String articulos=inicio+"/faces/articulos.xhtml";

    public String getInicio() {
        return inicio;
    }

    public void setInicio(String inicio) {
        this.inicio = inicio;
    }

    public String getClientes() {
        return clientes;
    }

    public void setClientes(String clientes) {
        this.clientes = clientes;
    }

    public String getArticulos() {
        return articulos;
    }

    public void setArticulos(String articulos) {
        this.articulos = articulos;
    }
    
    
}
