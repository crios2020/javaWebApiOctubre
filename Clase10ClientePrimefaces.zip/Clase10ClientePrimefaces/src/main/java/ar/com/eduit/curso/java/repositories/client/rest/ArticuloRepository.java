package ar.com.eduit.curso.java.repositories.client.rest;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ArticuloRepository implements I_ArticuloRepository{
    private String serverUrl;

    public ArticuloRepository(String serverUrl) {
        this.serverUrl = serverUrl;
    }

    @Override
    public void save(Articulo articulo) {
        if(articulo==null) return;
        String url=serverUrl+"/articulos/v1/alta?descripcion="+articulo.getDescripcion()
                +"&precio="+articulo.getPrecio()
                +"&stock="+articulo.getStock();
        try{
            String response=ClienteRest.responseBody(url);
            articulo.setId(Integer.parseInt(response));
        }catch(Exception e){
            System.out.println(e);
        }
    }

    @Override
    public void remove(Articulo articulo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Articulo> getAll() {
        String url=serverUrl+"/articulos/v1/all";
        List<Articulo>list=new ArrayList();
        try {
            String response=ClienteRest.responseBody(url);
            Type listType=new TypeToken<List<Articulo>>(){}.getType();
            list=new Gson().fromJson(response, listType);
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public List<Articulo> getLikeDescripcion(String descripcion) {
        if(descripcion==null) return new ArrayList();
        String url=serverUrl+"/articulos/v1/likeDescripcion?descripcion="+descripcion;
        List<Articulo>list=new ArrayList();
        try {
            String response=ClienteRest.responseBody(url);
            Type listType=new TypeToken<List<Articulo>>(){}.getType();
            list=new Gson().fromJson(response, listType);
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public Articulo getById(int id) {
        String url=serverUrl+"/articulos/v1/byId?id="+id;
        Articulo articulo=new Articulo();
        try {
            String response=ClienteRest.responseBody(url);
            Type type=new TypeToken<Articulo>(){}.getType();
            articulo=new Gson().fromJson(response, type);
        } catch (Exception e) {
            System.out.println(e);
        }
        return articulo;
    }
    
}
