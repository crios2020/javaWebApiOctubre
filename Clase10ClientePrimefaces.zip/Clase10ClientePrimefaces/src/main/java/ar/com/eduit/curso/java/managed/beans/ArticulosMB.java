package ar.com.eduit.curso.java.managed.beans;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.client.rest.ArticuloRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named()
@SessionScoped
public class ArticulosMB implements Serializable{
    private Articulo articulo=new Articulo();
    private String mensaje="";
    private String buscarDescripcion="";
    private I_ArticuloRepository ar=new ArticuloRepository("http://localhost:8082/Server/webresources");

    public void save(){
        try{
            ar.save(articulo);
            if(articulo.getId()!=0){
                mensaje="Se guardo el articulo id: "+articulo.getId();
                addMessage(FacesMessage.SEVERITY_INFO, "Info", mensaje);
                articulo=new Articulo();
            }else{
                mensaje="Error!! No se pudo guardar el articulo!";
                addMessage(FacesMessage.SEVERITY_ERROR, "Error", mensaje);
            }
        }catch(Exception e){
            mensaje="Error!! No se pudo guardar el articulo!";
            addMessage(FacesMessage.SEVERITY_ERROR, "Error", mensaje);
        }
    }
    
    public void addMessage(FacesMessage.Severity severity, String summary, String detail) {
        FacesContext.getCurrentInstance().
                addMessage(null, new FacesMessage(severity, summary, detail));
    }
    
    public List<Articulo>getAll(){
        return ar.getAll();
    }
    
    public List<Articulo>getLikeDescripcion(){
        return ar.getLikeDescripcion(buscarDescripcion);
    }
    
    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getBuscarDescripcion() {
        return buscarDescripcion;
    }

    public void setBuscarDescripcion(String buscarDescripcion) {
        this.buscarDescripcion = buscarDescripcion;
    }
      
}
