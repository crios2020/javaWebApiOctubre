package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.client.rest.ArticuloRepository;
import ar.com.eduit.curso.java.repositories.client.rest.ClienteRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;


public class TestRepository {
    public static void main(String[] args) {
        
        String urlServer="http://localhost:8082/Server/webresources";
        
        I_ArticuloRepository ar=new ArticuloRepository(urlServer);
        ar.save(new Articulo("Termo", 600, 20));
        ar.save(new Articulo("Pava_Electrica", 1600, 10));
        ar.save(new Articulo("Conservadora", 700, 22));
        ar.save(new Articulo("Luz_Camping", 500, 14));
        
        Articulo articulo=new Articulo("Linterna",20,20);
        ar.save(articulo);
        System.out.println(articulo);
        
        //ar.getAll().forEach(System.out::println);
        ar.getLikeDescripcion("ca").forEach(System.out::println);
        
        
        I_ClienteRepository cr=new ClienteRepository(urlServer);
        cr.save(new Cliente("Kassandra","Vargas",23,1));
        cr.save(new Cliente("Andrea","Moretti",26,2));
        cr.save(new Cliente("Javier","Correa",29,3));
        cr.save(new Cliente("Jimena","Riera",39,4));
        //cr.getAll().forEach(System.out::println);
        cr.getLikeApellido("ri").forEach(System.out::println);
        
        
    }
}
