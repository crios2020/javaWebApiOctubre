package ar.com.eduit.curso.java.repositories.client.rest;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ClienteRepository implements I_ClienteRepository{
    private String serverUrl;

    public ClienteRepository(String serverUrl) {
        this.serverUrl = serverUrl;
    }

    @Override
    public void save(Cliente cliente) {
        if(cliente==null) return;
        String url=serverUrl+"/clientes/v1/alta?nombre="+cliente.getNombre()
                +"&apellido="+cliente.getApellido()
                +"&edad="+cliente.getEdad()
                +"&idArticulo="+cliente.getIdArticulo();
        try{
            String response=ClienteRest.responseBody(url);
            cliente.setId(Integer.parseInt(response));
        }catch(Exception e){
            System.out.println(e);
        }
    }

    @Override
    public void remove(Cliente cliente) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Cliente> getAll() {
        String url=serverUrl+"/clientes/v1/all";
        List<Cliente>list=new ArrayList();
        try {
            String response=ClienteRest.responseBody(url);
            Type listType=new TypeToken<List<Cliente>>(){}.getType();
            list=new Gson().fromJson(response, listType);
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public List<Cliente> getLikeApellido(String apellido) {
        if(apellido==null) return new ArrayList();
        String url=serverUrl+"/clientes/v1/likeApellido?apellido="+apellido;
        List<Cliente>list=new ArrayList();
        try {
            String response=ClienteRest.responseBody(url);
            Type listType=new TypeToken<List<Cliente>>(){}.getType();
            list=new Gson().fromJson(response, listType);
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public Cliente getById(int id) {
        Cliente cliente=new Cliente();
        String url=serverUrl+"/clientes/v1/byId?id="+id;
        try {
            String response=ClienteRest.responseBody(url);
            Type type=new TypeToken<Cliente>(){}.getType();
            cliente=new Gson().fromJson(response, type);
        } catch (Exception e) {
            System.out.println(e);
        }
        return cliente;
    }
    
}
