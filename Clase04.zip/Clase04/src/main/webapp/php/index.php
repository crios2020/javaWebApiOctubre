<?php
	$nro1=$_REQUEST['nro1'];
	$nro2=$_REQUEST['nro2'];
	echo $nro1+$nro2;
?>
