drop database if exists javaWeb;
create database javaWeb;
use javaWeb;
drop table if exists articulos;
create table articulos(
    id int auto_increment primary key,
    descripcion varchar(50) not null,
    precio double not null,
    stock int not null
);
show tables;