package ar.com.eduit.curso.java.managed.beans;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ArticuloRepository;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named()
@SessionScoped
public class ArticulosMB implements Serializable{
    private Articulo articulo=new Articulo();
    private String mensaje="";
    private String buscarDescripcion="";
    private I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());

    public void save(){
        try{
            ar.save(articulo);
            if(articulo.getId()!=0){
                mensaje="Se guardo el articulo id: "+articulo.getId();
                articulo=new Articulo();
            }else{
                mensaje="Error!! No se pudo guardar el articulo!";
            }
        }catch(Exception e){
            mensaje="Error!! No se pudo guardar el articulo!";
        }
    }
    
    public List<Articulo>getAll(){
        return ar.getAll();
    }
    
    public List<Articulo>getLikeDescripcion(){
        return ar.getLikeDescripcion(buscarDescripcion);
    }
    
    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getBuscarDescripcion() {
        return buscarDescripcion;
    }

    public void setBuscarDescripcion(String buscarDescripcion) {
        this.buscarDescripcion = buscarDescripcion;
    }
      
}
