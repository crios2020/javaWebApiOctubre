package ar.com.eduit.curso.java.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Session extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Session</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Session at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Session</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>No se permite el ingreso de parametros por GET</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session=request.getSession();
        try (PrintWriter out = response.getWriter()) {
            String user=request.getParameter("user");
            String pass=request.getParameter("pass");
            if(user.equals("root") && pass.equals("123")){
                session.setAttribute("login", true);
                session.setAttribute("name", "root");
                response.sendRedirect("welcome.jsp");
            }else{
                session.setAttribute("login", false);
                session.setAttribute("name", "unknow");
                response.sendRedirect("errorLogin.html");
            }
        }
    }

}
