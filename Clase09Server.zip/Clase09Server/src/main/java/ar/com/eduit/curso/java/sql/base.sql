-- mariadb

drop database if exists javaWeb;
create database javaWeb;
use javaWeb;
 
drop table if exists clientes;
drop table if exists articulos;
create table articulos(
    id int auto_increment primary key,
    descripcion varchar(50) not null,
    precio double not null,
    stock int not null
);
create table clientes(
    id int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    edad int not null,
    idArticulo int not null
);
alter table clientes
    add constraint fk_clientes_idArticulo
    foreign key(idArticulo)
    references articulos(id);

show tables;


/*
-- postgresql
drop table if exists detalles;
drop table if exists articulos;
create table articulos(
    id serial primary key,
    descripcion varchar(50) not null,
    precio float8 not null,
    stock int not null
);
*/