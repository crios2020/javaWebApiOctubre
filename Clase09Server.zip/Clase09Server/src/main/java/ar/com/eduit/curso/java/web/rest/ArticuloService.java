package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ArticuloRepository;
import com.google.gson.Gson;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/articulos/v1")
public class ArticuloService {
    
    private I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio Articulos v1 Activo!";
    } 
    
    @GET
    @Path("/alta")
    @Produces(MediaType.TEXT_PLAIN)
    public String alta( @QueryParam("descripcion")String descripcion, 
                        @QueryParam("precio")double precio,
                        @QueryParam("stock")int stock){
        Articulo articulo=new Articulo(descripcion, precio, stock);
        ar.save(articulo);      
        return articulo.getId()+"";
    }
    
    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public String all(){
        return new Gson().toJson(ar.getAll());
    }
    
    @GET
    @Path("/likeDescripcion")
    @Produces(MediaType.APPLICATION_JSON)
    public String likeDescripcion(@QueryParam("descripcion")String descripcion){
        return new Gson().toJson(ar.getLikeDescripcion(descripcion));
    }
}
