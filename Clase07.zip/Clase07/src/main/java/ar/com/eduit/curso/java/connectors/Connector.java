package ar.com.eduit.curso.java.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
    
    private static Connection conn=null;
    
//    private static String driver="org.mariadb.jdbc.Driver";
//    private static String url="jdbc:mariadb://localhost:3306/javaWeb";
//    private static String user="root";
//    private static String pass="";
    
    private static String driver="org.mariadb.jdbc.Driver";
    private static String url="jdbc:mariadb://db4free.net:3306/java_web";
    private static String user="java_web";
    private static String pass="java_web";
    
//    private static String driver="org.postgresql.Driver";
//    private static String url="jdbc:postgresql://kesavan.db.elephantsql.com:5432/kwugovfe";
//    private static String user="kwugovfe";
//    private static String pass="e3SF33nVwgZkZjAOzjT4Bs8MHuWcyfD6";
    
    private Connector(){}
    public static Connection getConnection(){
        try {
            if(conn==null || conn.isClosed()){
                Class.forName(driver);
                conn=DriverManager.getConnection(url, user, pass);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return conn;
    }
}
